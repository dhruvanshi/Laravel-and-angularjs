<?php
class onlineExams extends Eloquent {
	public $timestamps = false;
	protected $table = 'onlineExams';
}