<?php
class Modules extends Eloquent {
	public $timestamps = false;
	protected $table = 'modules';
}