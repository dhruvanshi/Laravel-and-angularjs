<?php
class learnPath extends Eloquent {
	public $timestamps = false;
	protected $table = 'learnPath';
}