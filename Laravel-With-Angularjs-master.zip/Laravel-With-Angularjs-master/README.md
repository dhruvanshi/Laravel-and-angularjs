# Laravel-With-Angularjs

Sample of School Management System with Angular JS
1. Login/Registration Script
2. Online Exam Module. Add/Edit/Delete, Take Online exam, View exam schedules
3. Learn Path Module. Add/Edit/Delete, View study guides for student based on there grade in class exam, online exam and assignment. Students can see study modules for every subjects based on there grade in that subject. There are differenct levels of learn path base on grade of student, where set of assignments, exams and online exam are assign to students.
   
 All the things are done using Angular Js.
   
